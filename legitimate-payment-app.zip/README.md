# Legitimate Payment Instructions App

A mobile-first payment instruction page inspired by the supplied reference layout.

## URL parameters

The page accepts:

- `amntInput` — amount
- `nameInput` — payee/customer name
- `vpaInput` — UPI ID

Example:

`index.html?amntInput=3060&nameInput=Customer%20Name&vpaInput=merchant@upi`

## Important production note

This frontend does **not** verify payments. It only records the UTR/reference entered by the customer in local browser storage for demo purposes.

For production:
1. Use your own authorized merchant/payment provider.
2. Verify payment server-to-server/webhook before marking an invoice as paid.
3. Never tell a customer that a UTR submission alone means payment succeeded.
4. Add authentication, HTTPS, server-side validation, rate limiting and audit logs.
5. Keep secrets/API keys out of browser JavaScript.

## Deploy to Vercel

Upload this folder to a Git repository and import it into Vercel, or use the Vercel CLI.

No build step is required.
